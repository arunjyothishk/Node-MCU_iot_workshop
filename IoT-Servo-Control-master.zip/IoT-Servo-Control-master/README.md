# IoT-Servo-Control
Controlling Servos over internet 

The complete tutorial can be found here:
https://www.instructables.com/id/IoT-Made-Simple-Servo-Control-With-NodeMCU-and-Bly/
